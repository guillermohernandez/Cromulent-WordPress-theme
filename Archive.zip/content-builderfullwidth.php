<?php
/**
 * The template used for displaying page content in page-builderfullwidth.php
 *
 * @package Cromulent
 * @since Cromulent 1.3.2
 */
?>

	<?php the_content(); ?>
